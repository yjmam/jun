/*
// header - edit "Data/yourJavaHeader" to customize
// contents - edit "EventHandlers/Java file/onCreate" to customize
//
*/
import java.awt.*;

public class FrameEx2 extends Frame
{
	public FrameEx2()
	{
		super("������ �׽�Ʈ");

		setSize(300,300);
		setVisible(true);
	}
	public static void main(String args[])
	{
		FrameEx2 fe=new FrameEx2();		
	}
}

