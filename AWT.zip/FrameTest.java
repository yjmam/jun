/*
// header - edit "Data/yourJavaHeader" to customize
// contents - edit "EventHandlers/Java file/onCreate" to customize
//
*/
import java.awt.*;

class FrameTest
{
	public static void main(String args[])
	{
		Frame f = new Frame();
		
		f.setSize(300,300);
		f.setVisible(true);
		
		
	}

}

